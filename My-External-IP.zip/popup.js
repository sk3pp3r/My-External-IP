var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://ip-api.com/json', true);
xhr.responseType = 'json';
xhr.onload = function() {
var status = xhr.status;
if (status === 200) {
document.getElementById('ip').innerHTML = xhr.response.query;
} else {
console.log('Error: ' + status);
}
};
xhr.send();